# SDAC-Team Example Repo

> **A real-world example of multi-human + multi-AI collaboration under SDAC-Team**

这是一个**完整的、可复刻的 repo 级示例**，展示：
- 多人（Spec Owner / Module Owner / Release Owner）
- 多 AI Worker 并行
- 在 SDAC-Team 约束下如何稳定推进一个真实项目

项目类型：**Canvas Game（简化版）**
