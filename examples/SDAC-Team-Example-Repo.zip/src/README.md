src 目录仅用于示例说明结构：
- player/
- weapon/
- ai/
- state/
