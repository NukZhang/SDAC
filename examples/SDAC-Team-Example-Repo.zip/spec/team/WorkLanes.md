# Work Lanes

## Iteration 1

### Lane A — Player
Allowed:
- src/player/**

### Lane B — Weapon
Allowed:
- src/weapon/**
