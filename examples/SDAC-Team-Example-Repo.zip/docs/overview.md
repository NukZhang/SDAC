# 项目概览

目标：实现一个可运行的 Canvas Game Demo，包含：
- Player
- Weapon（Bow）
- Enemy AI
- State Machine

约束：
- AI 只做行级实现
- 所有需求通过 Me2AI
- 并行开发但串行集成
