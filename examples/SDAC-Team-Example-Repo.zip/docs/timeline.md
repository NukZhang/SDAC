# 实战时间线（示例）

## Day 1
- SO 定义 Iteration 1
- 拆分 Lane A / Lane B

## Day 2
- AI-W(A) 实现 Player 移动
- AI-W(B) 实现 Bow 攻击

## Day 3
- RO 串行合并
- 运行 Demo
